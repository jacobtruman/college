Module mdlShared

    ' Login related declarations
    Public UserID, Permission As String
    Public Login As New frmLogin
    Public ChangeLogin As New frmChangeLogin

    ' New registration related declarations
    Public Register As New frmNewRegister

    ' Student Function related declarations
    Public Studentfunctions As New frmStudentFunctions
    Public MakeAppointment As New frmAppointment
    Public EditProfile As New frmProfile

    ' Advisor functions related declarations
    Public AdvisorFunctions As New frmAdvisorFunctions
    Public ManageSchedule As New frmAdvisor

End Module
