Imports System.Data.OleDb

Public Class frmAppointment
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents lblMain As System.Windows.Forms.Label
    Friend WithEvents picLogo As System.Windows.Forms.PictureBox
    Friend WithEvents lblMainMsg As System.Windows.Forms.Label
    Friend WithEvents cbxAdvisor As System.Windows.Forms.ComboBox
    Friend WithEvents cbxReason As System.Windows.Forms.ComboBox
    Friend WithEvents txtComments As System.Windows.Forms.TextBox
    Friend WithEvents lblComments As System.Windows.Forms.Label
    Friend WithEvents lblReason As System.Windows.Forms.Label
    Friend WithEvents calAppointment As System.Windows.Forms.MonthCalendar
    Friend WithEvents btnSubmit As System.Windows.Forms.Button
    Friend WithEvents lblAdvisor As System.Windows.Forms.Label
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox2 As System.Windows.Forms.ListBox
    Friend WithEvents txtTm2 As System.Windows.Forms.Label
    Friend WithEvents txtTm3 As System.Windows.Forms.Label
    Friend WithEvents txtTm4 As System.Windows.Forms.Label
    Friend WithEvents txtTm5 As System.Windows.Forms.Label
    Friend WithEvents txtTm9 As System.Windows.Forms.Label
    Friend WithEvents txtTm8 As System.Windows.Forms.Label
    Friend WithEvents txtTm7 As System.Windows.Forms.Label
    Friend WithEvents txtTm6 As System.Windows.Forms.Label
    Friend WithEvents txtTm17 As System.Windows.Forms.Label
    Friend WithEvents txtTm16 As System.Windows.Forms.Label
    Friend WithEvents txtTm15 As System.Windows.Forms.Label
    Friend WithEvents txtTm14 As System.Windows.Forms.Label
    Friend WithEvents txtTm13 As System.Windows.Forms.Label
    Friend WithEvents txtTm12 As System.Windows.Forms.Label
    Friend WithEvents txtTm11 As System.Windows.Forms.Label
    Friend WithEvents txtTm10 As System.Windows.Forms.Label
    Friend WithEvents txtTm1 As System.Windows.Forms.Label
    Friend WithEvents txtTm0 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents ListView1 As System.Windows.Forms.ListView
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmAppointment))
        Me.lblMain = New System.Windows.Forms.Label
        Me.picLogo = New System.Windows.Forms.PictureBox
        Me.lblMainMsg = New System.Windows.Forms.Label
        Me.cbxAdvisor = New System.Windows.Forms.ComboBox
        Me.cbxReason = New System.Windows.Forms.ComboBox
        Me.txtComments = New System.Windows.Forms.TextBox
        Me.lblComments = New System.Windows.Forms.Label
        Me.lblReason = New System.Windows.Forms.Label
        Me.calAppointment = New System.Windows.Forms.MonthCalendar
        Me.btnSubmit = New System.Windows.Forms.Button
        Me.lblAdvisor = New System.Windows.Forms.Label
        Me.ListBox1 = New System.Windows.Forms.ListBox
        Me.ListBox2 = New System.Windows.Forms.ListBox
        Me.txtTm2 = New System.Windows.Forms.Label
        Me.txtTm3 = New System.Windows.Forms.Label
        Me.txtTm4 = New System.Windows.Forms.Label
        Me.txtTm5 = New System.Windows.Forms.Label
        Me.txtTm9 = New System.Windows.Forms.Label
        Me.txtTm8 = New System.Windows.Forms.Label
        Me.txtTm7 = New System.Windows.Forms.Label
        Me.txtTm6 = New System.Windows.Forms.Label
        Me.txtTm17 = New System.Windows.Forms.Label
        Me.txtTm16 = New System.Windows.Forms.Label
        Me.txtTm15 = New System.Windows.Forms.Label
        Me.txtTm14 = New System.Windows.Forms.Label
        Me.txtTm13 = New System.Windows.Forms.Label
        Me.txtTm12 = New System.Windows.Forms.Label
        Me.txtTm11 = New System.Windows.Forms.Label
        Me.txtTm10 = New System.Windows.Forms.Label
        Me.txtTm1 = New System.Windows.Forms.Label
        Me.txtTm0 = New System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.ListView1 = New System.Windows.Forms.ListView
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblMain
        '
        Me.lblMain.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblMain.Font = New System.Drawing.Font("Garamond", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMain.Location = New System.Drawing.Point(16, 8)
        Me.lblMain.Name = "lblMain"
        Me.lblMain.Size = New System.Drawing.Size(360, 112)
        Me.lblMain.TabIndex = 38
        Me.lblMain.Text = "College of Business Undergraduate Advising Appointments System"
        '
        'picLogo
        '
        Me.picLogo.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.picLogo.Image = CType(resources.GetObject("picLogo.Image"), System.Drawing.Image)
        Me.picLogo.Location = New System.Drawing.Point(376, 0)
        Me.picLogo.Name = "picLogo"
        Me.picLogo.Size = New System.Drawing.Size(264, 136)
        Me.picLogo.TabIndex = 39
        Me.picLogo.TabStop = False
        '
        'lblMainMsg
        '
        Me.lblMainMsg.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblMainMsg.Font = New System.Drawing.Font("Times New Roman", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMainMsg.Location = New System.Drawing.Point(640, 8)
        Me.lblMainMsg.Name = "lblMainMsg"
        Me.lblMainMsg.Size = New System.Drawing.Size(360, 112)
        Me.lblMainMsg.TabIndex = 41
        Me.lblMainMsg.Text = "Attention! Messages Go Here. No appointments necessary to drop off signed documen" & _
        "ts."
        Me.lblMainMsg.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cbxAdvisor
        '
        Me.cbxAdvisor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbxAdvisor.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbxAdvisor.Location = New System.Drawing.Point(176, 200)
        Me.cbxAdvisor.Name = "cbxAdvisor"
        Me.cbxAdvisor.Size = New System.Drawing.Size(120, 32)
        Me.cbxAdvisor.TabIndex = 55
        '
        'cbxReason
        '
        Me.cbxReason.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbxReason.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbxReason.Location = New System.Drawing.Point(208, 248)
        Me.cbxReason.Name = "cbxReason"
        Me.cbxReason.Size = New System.Drawing.Size(160, 27)
        Me.cbxReason.TabIndex = 57
        '
        'txtComments
        '
        Me.txtComments.Location = New System.Drawing.Point(24, 328)
        Me.txtComments.Multiline = True
        Me.txtComments.Name = "txtComments"
        Me.txtComments.Size = New System.Drawing.Size(264, 48)
        Me.txtComments.TabIndex = 59
        Me.txtComments.Text = ""
        '
        'lblComments
        '
        Me.lblComments.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblComments.Location = New System.Drawing.Point(104, 296)
        Me.lblComments.Name = "lblComments"
        Me.lblComments.Size = New System.Drawing.Size(88, 23)
        Me.lblComments.TabIndex = 60
        Me.lblComments.Text = "Comments"
        '
        'lblReason
        '
        Me.lblReason.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblReason.Location = New System.Drawing.Point(24, 248)
        Me.lblReason.Name = "lblReason"
        Me.lblReason.Size = New System.Drawing.Size(192, 23)
        Me.lblReason.TabIndex = 58
        Me.lblReason.Text = "Reason for Appointment:"
        Me.lblReason.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'calAppointment
        '
        Me.calAppointment.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.calAppointment.Location = New System.Drawing.Point(16, 448)
        Me.calAppointment.Name = "calAppointment"
        Me.calAppointment.TabIndex = 52
        Me.calAppointment.TitleBackColor = System.Drawing.Color.Red
        Me.calAppointment.TitleForeColor = System.Drawing.SystemColors.WindowText
        Me.calAppointment.TrailingForeColor = System.Drawing.SystemColors.InactiveCaptionText
        '
        'btnSubmit
        '
        Me.btnSubmit.BackColor = System.Drawing.Color.MistyRose
        Me.btnSubmit.Font = New System.Drawing.Font("Times New Roman", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSubmit.Location = New System.Drawing.Point(64, 384)
        Me.btnSubmit.Name = "btnSubmit"
        Me.btnSubmit.Size = New System.Drawing.Size(128, 40)
        Me.btnSubmit.TabIndex = 42
        Me.btnSubmit.Text = "Submit"
        '
        'lblAdvisor
        '
        Me.lblAdvisor.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAdvisor.Location = New System.Drawing.Point(24, 208)
        Me.lblAdvisor.Name = "lblAdvisor"
        Me.lblAdvisor.Size = New System.Drawing.Size(152, 24)
        Me.lblAdvisor.TabIndex = 54
        Me.lblAdvisor.Text = "Select Advisor:"
        Me.lblAdvisor.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'ListBox1
        '
        Me.ListBox1.Items.AddRange(New Object() {"8:10", "8:40", "9:10", "9:40", "10:10", "10:40", "11:10", "11:40", "12:10", "12:40", "1:10", "1:40", "2:10", "2:40", "3:10", "3:40", "4:10", "4:40"})
        Me.ListBox1.Location = New System.Drawing.Point(824, 256)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(40, 238)
        Me.ListBox1.TabIndex = 62
        '
        'ListBox2
        '
        Me.ListBox2.Location = New System.Drawing.Point(680, 136)
        Me.ListBox2.Name = "ListBox2"
        Me.ListBox2.Size = New System.Drawing.Size(120, 290)
        Me.ListBox2.TabIndex = 63
        '
        'txtTm2
        '
        Me.txtTm2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtTm2.Location = New System.Drawing.Point(16, 80)
        Me.txtTm2.Name = "txtTm2"
        Me.txtTm2.Size = New System.Drawing.Size(35, 13)
        Me.txtTm2.TabIndex = 64
        Me.txtTm2.Text = "9:10"
        Me.txtTm2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtTm3
        '
        Me.txtTm3.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtTm3.Location = New System.Drawing.Point(16, 96)
        Me.txtTm3.Name = "txtTm3"
        Me.txtTm3.Size = New System.Drawing.Size(35, 13)
        Me.txtTm3.TabIndex = 65
        Me.txtTm3.Text = "9:40"
        Me.txtTm3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtTm4
        '
        Me.txtTm4.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtTm4.Location = New System.Drawing.Point(16, 112)
        Me.txtTm4.Name = "txtTm4"
        Me.txtTm4.Size = New System.Drawing.Size(35, 13)
        Me.txtTm4.TabIndex = 66
        Me.txtTm4.Text = "10:10"
        Me.txtTm4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtTm5
        '
        Me.txtTm5.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtTm5.Location = New System.Drawing.Point(16, 128)
        Me.txtTm5.Name = "txtTm5"
        Me.txtTm5.Size = New System.Drawing.Size(35, 13)
        Me.txtTm5.TabIndex = 67
        Me.txtTm5.Text = "10:40"
        Me.txtTm5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtTm9
        '
        Me.txtTm9.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtTm9.Location = New System.Drawing.Point(16, 192)
        Me.txtTm9.Name = "txtTm9"
        Me.txtTm9.Size = New System.Drawing.Size(35, 13)
        Me.txtTm9.TabIndex = 71
        Me.txtTm9.Text = "12:40"
        Me.txtTm9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtTm8
        '
        Me.txtTm8.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtTm8.Location = New System.Drawing.Point(16, 176)
        Me.txtTm8.Name = "txtTm8"
        Me.txtTm8.Size = New System.Drawing.Size(35, 13)
        Me.txtTm8.TabIndex = 70
        Me.txtTm8.Text = "12:10"
        Me.txtTm8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtTm7
        '
        Me.txtTm7.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtTm7.Location = New System.Drawing.Point(16, 160)
        Me.txtTm7.Name = "txtTm7"
        Me.txtTm7.Size = New System.Drawing.Size(35, 13)
        Me.txtTm7.TabIndex = 69
        Me.txtTm7.Text = "11:40"
        Me.txtTm7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtTm6
        '
        Me.txtTm6.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtTm6.Location = New System.Drawing.Point(16, 144)
        Me.txtTm6.Name = "txtTm6"
        Me.txtTm6.Size = New System.Drawing.Size(35, 13)
        Me.txtTm6.TabIndex = 68
        Me.txtTm6.Text = "11:10"
        Me.txtTm6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtTm17
        '
        Me.txtTm17.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtTm17.Location = New System.Drawing.Point(16, 320)
        Me.txtTm17.Name = "txtTm17"
        Me.txtTm17.Size = New System.Drawing.Size(35, 13)
        Me.txtTm17.TabIndex = 79
        Me.txtTm17.Text = "4:40"
        Me.txtTm17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtTm16
        '
        Me.txtTm16.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtTm16.Location = New System.Drawing.Point(16, 304)
        Me.txtTm16.Name = "txtTm16"
        Me.txtTm16.Size = New System.Drawing.Size(35, 13)
        Me.txtTm16.TabIndex = 78
        Me.txtTm16.Text = "4:10"
        Me.txtTm16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtTm15
        '
        Me.txtTm15.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtTm15.Location = New System.Drawing.Point(16, 288)
        Me.txtTm15.Name = "txtTm15"
        Me.txtTm15.Size = New System.Drawing.Size(35, 13)
        Me.txtTm15.TabIndex = 77
        Me.txtTm15.Text = "3:40"
        Me.txtTm15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtTm14
        '
        Me.txtTm14.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtTm14.Location = New System.Drawing.Point(16, 272)
        Me.txtTm14.Name = "txtTm14"
        Me.txtTm14.Size = New System.Drawing.Size(35, 13)
        Me.txtTm14.TabIndex = 76
        Me.txtTm14.Text = "3:10"
        Me.txtTm14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtTm13
        '
        Me.txtTm13.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtTm13.Location = New System.Drawing.Point(16, 256)
        Me.txtTm13.Name = "txtTm13"
        Me.txtTm13.Size = New System.Drawing.Size(35, 13)
        Me.txtTm13.TabIndex = 75
        Me.txtTm13.Text = "2:40"
        Me.txtTm13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtTm12
        '
        Me.txtTm12.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtTm12.Location = New System.Drawing.Point(16, 240)
        Me.txtTm12.Name = "txtTm12"
        Me.txtTm12.Size = New System.Drawing.Size(35, 13)
        Me.txtTm12.TabIndex = 74
        Me.txtTm12.Text = "2:10"
        Me.txtTm12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtTm11
        '
        Me.txtTm11.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtTm11.Location = New System.Drawing.Point(16, 224)
        Me.txtTm11.Name = "txtTm11"
        Me.txtTm11.Size = New System.Drawing.Size(35, 13)
        Me.txtTm11.TabIndex = 73
        Me.txtTm11.Text = "1:40"
        Me.txtTm11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtTm10
        '
        Me.txtTm10.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtTm10.Location = New System.Drawing.Point(16, 208)
        Me.txtTm10.Name = "txtTm10"
        Me.txtTm10.Size = New System.Drawing.Size(35, 13)
        Me.txtTm10.TabIndex = 72
        Me.txtTm10.Text = "1:10"
        Me.txtTm10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtTm1
        '
        Me.txtTm1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtTm1.Location = New System.Drawing.Point(16, 64)
        Me.txtTm1.Name = "txtTm1"
        Me.txtTm1.Size = New System.Drawing.Size(35, 13)
        Me.txtTm1.TabIndex = 81
        Me.txtTm1.Text = "8:40"
        Me.txtTm1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtTm0
        '
        Me.txtTm0.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtTm0.Location = New System.Drawing.Point(16, 48)
        Me.txtTm0.Name = "txtTm0"
        Me.txtTm0.Size = New System.Drawing.Size(35, 13)
        Me.txtTm0.TabIndex = 80
        Me.txtTm0.Text = "8:10"
        Me.txtTm0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.ListView1)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.txtTm11)
        Me.GroupBox1.Controls.Add(Me.txtTm10)
        Me.GroupBox1.Controls.Add(Me.txtTm2)
        Me.GroupBox1.Controls.Add(Me.txtTm16)
        Me.GroupBox1.Controls.Add(Me.txtTm17)
        Me.GroupBox1.Controls.Add(Me.txtTm15)
        Me.GroupBox1.Controls.Add(Me.txtTm14)
        Me.GroupBox1.Controls.Add(Me.txtTm5)
        Me.GroupBox1.Controls.Add(Me.txtTm1)
        Me.GroupBox1.Controls.Add(Me.txtTm0)
        Me.GroupBox1.Controls.Add(Me.txtTm7)
        Me.GroupBox1.Controls.Add(Me.txtTm6)
        Me.GroupBox1.Controls.Add(Me.txtTm4)
        Me.GroupBox1.Controls.Add(Me.txtTm9)
        Me.GroupBox1.Controls.Add(Me.txtTm8)
        Me.GroupBox1.Controls.Add(Me.txtTm13)
        Me.GroupBox1.Controls.Add(Me.txtTm12)
        Me.GroupBox1.Controls.Add(Me.txtTm3)
        Me.GroupBox1.Location = New System.Drawing.Point(296, 320)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(360, 344)
        Me.GroupBox1.TabIndex = 82
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "GroupBox1"
        '
        'ListView1
        '
        Me.ListView1.GridLines = True
        Me.ListView1.Location = New System.Drawing.Point(72, 48)
        Me.ListView1.Name = "ListView1"
        Me.ListView1.Size = New System.Drawing.Size(280, 288)
        Me.ListView1.TabIndex = 83
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(16, 24)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(40, 16)
        Me.Label1.TabIndex = 82
        Me.Label1.Text = "Day 1"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(80, 24)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(64, 16)
        Me.Label2.TabIndex = 84
        Me.Label2.Text = "advisor a"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(184, 24)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(64, 16)
        Me.Label3.TabIndex = 85
        Me.Label3.Text = "advisor b"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(288, 24)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(56, 16)
        Me.Label4.TabIndex = 86
        Me.Label4.Text = "advisor c"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'frmAppointment
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.Color.WhiteSmoke
        Me.ClientSize = New System.Drawing.Size(1016, 677)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.ListBox2)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.cbxAdvisor)
        Me.Controls.Add(Me.cbxReason)
        Me.Controls.Add(Me.txtComments)
        Me.Controls.Add(Me.lblComments)
        Me.Controls.Add(Me.lblReason)
        Me.Controls.Add(Me.calAppointment)
        Me.Controls.Add(Me.btnSubmit)
        Me.Controls.Add(Me.lblAdvisor)
        Me.Controls.Add(Me.lblMainMsg)
        Me.Controls.Add(Me.lblMain)
        Me.Controls.Add(Me.picLogo)
        Me.Name = "frmAppointment"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "COB Advising - Make Appointment"
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Dim db As String = "..\..\..\DB\COBAdvisingAppts.mdb"
    Dim dbCon As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & Application.StartupPath & db & "; Persist Security Info=False;"
    Dim sql As String
    Dim blockOut() As Integer = {8, 9}
    Dim selFlag As Boolean = False


    Private Sub frmAppointment_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        Studentfunctions.Visible = True
    End Sub

    Private Sub frmAppointment_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim objread As OleDbDataReader
        Dim oledbcon As New OleDbConnection(dbCon)







        Dim con As OleDb.OleDbConnection
        Dim connectionString As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Documents and Settings\Administrator\Desktop\IS 389 Projectjacob\IS 389 Project\DB\COBAdvisingAppts.mdb"
        con = New OleDb.OleDbConnection(connectionString)
        Dim ds As New DataSet
        Dim da As OleDb.OleDbDataAdapter, dt As DataTable
        Dim dr As DataRow
        da = New OleDb.OleDbDataAdapter("SELECT * FROM Appointment", con)
        da.Fill(ds)
        ListView1.Items.Clear()

        'Repeat for each table in the DataSet collection.
        For Each dt In ds.Tables
            'Repeat for each row in the table.
            For Each dr In dt.Rows
                ListView1.Items.Add(dr("ADate"))
                ListView1.Items(0).SubItems.Add(dr("ATime"))
                ListView1.Items(0).SubItems.Add(dr("Student"))
            Next
        Next












        Try
            oledbcon.Open()

            sql = "SELECT ATime FROM Appointment WHERE ADate > '04/16/2006' AND ADate < '04/20/2006' ORDER BY ATime"
            Dim cmd As OleDbCommand = New OleDbCommand(sql, oledbcon)
            objread = cmd.ExecuteReader

            Dim iCounter, jCounter As Integer
            Dim tm0, tm1, tm2, tm3, tm4, tm5, tm6, tm7, tm8, tm9, tm10, tm11, tm12, tm13, tm14, tm15, tm16, tm17 As Integer
            Dim fCounter() As Object = {tm0, tm1, tm2, tm3, tm4, tm5, tm6, tm7, tm8, tm9, tm10, tm11, tm12, tm13, tm14, tm15, tm16, tm17}
            Dim txtCounter() As Object = {txtTm0, txtTm1, txtTm2, txtTm3, txtTm4, txtTm5, txtTm6, txtTm7, txtTm8, txtTm9, txtTm10, txtTm11, txtTm12, txtTm13, txtTm14, txtTm15, txtTm16, txtTm17}

            For iCounter = 0 To UBound(blockOut)
                txtCounter(blockOut(iCounter)).Enabled = False
            Next

            For jCounter = 0 To 17
                While objread.Read
                    For iCounter = 0 To objread.FieldCount() - 1
                        If (txtCounter(jCounter).Text = objread.GetValue(iCounter)) Then
                            fCounter(jCounter) += 1
                            If (fCounter(jCounter) >= 3) Then
                                txtCounter(jCounter).Enabled = False
                            End If
                        End If
                    Next
                End While
                objread.Close()
                objread = cmd.ExecuteReader
                ListBox2.Items.Add(fCounter(jCounter))
            Next

            objread.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            oledbcon.Close()
        End Try
    End Sub

    Private Sub txtTm0_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtTm0.Click
        selColors(txtTm0)
    End Sub

    Private Sub txtTm1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtTm1.Click
        selColors(txtTm1)
    End Sub

    Private Sub txtTm2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtTm2.Click
        selColors(txtTm2)
    End Sub

    Private Sub txtTm1_MouseHover(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtTm1.MouseHover
        onColors(txtTm1)
    End Sub

    Private Sub txtTm2_MouseHover(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtTm2.MouseHover
        onColors(txtTm2)
    End Sub

    Private Sub txtTm1_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtTm1.MouseLeave
        offColors(txtTm1)
    End Sub

    Private Sub txtTm2_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtTm2.MouseLeave
        offColors(txtTm2)
    End Sub

    Private Function onColors(ByVal theObj As Object)
        'theObj.BackColor = System.Drawing.Color.Blue
        'theObj.ForeColor = System.Drawing.Color.White
        theObj.ForeColor = System.Drawing.Color.Blue
        theObj.Cursor = Cursors.Hand
    End Function

    Private Function offColors(ByVal theObj As Object)
        If selFlag = False Then
            theObj.BackColor = System.Drawing.Color.WhiteSmoke
            theObj.ForeColor = System.Drawing.Color.Black
        Else
            theObj.ForeColor = System.Drawing.Color.White
        End If
    End Function

    Private Function selColors(ByVal theObj As Object)
        theObj.BackColor = System.Drawing.Color.Red
        theObj.ForeColor = System.Drawing.Color.White
        selFlag = True
    End Function



    Private Sub ListView1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListView1.SelectedIndexChanged
        ListView1.FocusedItem.ForeColor = System.Drawing.Color.Red

    End Sub
End Class
