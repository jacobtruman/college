Public Class frmMain
    Inherits System.Windows.Forms.Form

    ' Create and initialize Circlae class
    Private objCircle As Graphics = CreateGraphics()
    ' Set diameter of Circle
    Private Const c_intDiameter As Integer = 25

    'Create Random class
    Dim objRandom As Random = New Random

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents btnRun As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.btnRun = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'btnRun
        '
        Me.btnRun.Location = New System.Drawing.Point(208, 232)
        Me.btnRun.Name = "btnRun"
        Me.btnRun.TabIndex = 0
        Me.btnRun.Text = "Run"
        '
        'frmMain
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(292, 273)
        Me.Controls.Add(Me.btnRun)
        Me.Name = "frmMain"
        Me.Text = "Jacob Truman"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub btnRun_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRun.Click
        Const numRows = 8, numSeats = 8
        Dim seatArray As Integer(,) = New Integer(numSeats, numRows) {}
        Dim solnArray As Integer(,) = New Integer(numSeats, numRows) {}
        Dim g_Left, g_Top, g_Left2, g_Top2, c_intDiameter2, posX1, posY1 As Integer
        Dim iCounter, jCounter, intChance As Integer

        ' Create and display an array representing occupied seats
        g_Left = 0
        g_Top = 0
        For iCounter = numRows To 1 Step -1
            For jCounter = 1 To numSeats
                intChance = objRandom.Next(1, 11)
                If intChance <= 9 Then
                    seatArray(jCounter, iCounter) = 1
                    objCircle.FillEllipse(New SolidBrush(Color.Red), _
                        g_Left, g_Top, c_intDiameter, c_intDiameter)
                Else
                    seatArray(jCounter, iCounter) = 0
                    objCircle.FillEllipse(New SolidBrush(Color.Black), _
                        g_Left, g_Top, c_intDiameter, c_intDiameter)
                End If
                g_Left += c_intDiameter * 1.1
            Next
            g_Left = 0
            g_Top += c_intDiameter * 1.1
        Next

        ' Initialize the solution array with zeros
        For iCounter = numRows To 1 Step -1
            For jCounter = 1 To numSeats
                solnArray(jCounter, iCounter) = 0
            Next
        Next

        ' Set the Start and End positions
        posX1 = objRandom.Next(1, 9)
        posY1 = 1
        solnArray(posX1, posY1) = 1

        ' Repaint seating arrangement, showing Start position
        g_Left = 0
        g_Top = 0
        For iCounter = numRows To 1 Step -1
            For jCounter = 1 To numSeats
                If seatArray(jCounter, iCounter) = 1 Then
                    objCircle.FillEllipse(New SolidBrush(Color.Red), _
                        g_Left, g_Top, c_intDiameter, c_intDiameter)
                    If solnArray(jCounter, iCounter) = 1 Then
                        g_Left2 = g_Left + (c_intDiameter - c_intDiameter2) / 2
                        g_Top2 = g_Top + (c_intDiameter - c_intDiameter2) / 2
                        objCircle.FillEllipse(New SolidBrush(Color.Green), _
                            g_Left2, g_Top2, c_intDiameter2, c_intDiameter2)
                    End If
                Else
                    objCircle.FillEllipse(New SolidBrush(Color.Black), _
                        g_Left, g_Top, c_intDiameter, c_intDiameter)
                    If solnArray(jCounter, iCounter) = 1 Then
                        g_Left2 = g_Left + (c_intDiameter - c_intDiameter2) / 2
                        g_Top2 = g_Top + (c_intDiameter - c_intDiameter2) / 2
                        objCircle.FillEllipse(New SolidBrush(Color.White), _
                            g_Left2, g_Top2, c_intDiameter2, c_intDiameter2)
                    End If
                End If
                g_Left += c_intDiameter * 1.1
            Next
            g_Left = 0
            g_Top += c_intDiameter * 1.1
        Next
        MsgBox("Start position = (" & posX1 & ", " & posY1 & ")")
    End Sub
End Class
